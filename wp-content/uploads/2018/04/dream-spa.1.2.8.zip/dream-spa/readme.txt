Dream Spa Theme README.

Dream Spa is an elegant WordPress child theme of Spasalon theme. Its perfect for building an online store. The theme suitable for spa, salons, beauty, care, girly, hair, health, hospitality, massage, medical, parlor, physiotherapy, wellness, yoga, health blog and for any type of businesses. Create an effective online shop presence since theme have a support for very famous plugin, WooCommerce. Separate Woocommerce Sidebar added in the shop pages so that you can add different set of widgets from default templates. You can customize the layouts of sidebars on Business Template without adding a single line of code. Navigate to Appearance > Customize to start customizing. Check premium version theme demo at http://webriti.com/demo/wp/dream-spa/

Images
Screenshot & Banner Image : CCO by skeeze
Screenshot Image...
https://pixabay.com/en/toner-skin-skincare-cooling-facial-906142/

Banner Images...
https://pixabay.com/en/wellness-massage-reiki-285590/

Slider Banner Thumbnail Image : CCO by rhythmuswege
https://pixabay.com/en/wellness-massage-sound-massage-285588/

== Credits ==


Based on Spasalon http://webriti.com/spasalon-lite-description/, (C) 2012-2016 Webriti, [GPLv3 or later](https://www.gnu.org/licenses/gpl-3.0.html)

DreamSpa WordPress Theme, Copyright 2016 Webriti Theme
DreamSpa is distributed under the terms of the GNU GPL

The Parent theme Spasalon needs to be installed for this DreamSpa to work.
Install
-------
1. Download "Spasalon" parent theme from https://wordpress.org/themes/spasalon/
2. Go to your WordPress dashboard and select Appearance > Install, click Upload link.
3. Upload both Spasalon and DreamSpa Theme, then activate the DreamSpa Theme

@version 1.2.8
1. Added import dummy data setting.
@version 1.2.7
1. Updated Strings.
@version 1.2.6
1. Update theme Descritpiton.
@version 1.2.5
1. Add Read More Button in Banner.
@version 1.2.4
1. Remove Pink Banner Strip.
2. Add New variation of slider.
@version 1.2.3
1. Update styling and solved theme review issue.
@version 1.2.2
1. Solved Theme Review Issue.
@version 1.2.1
1. Solved Theme Review Issue.
@version 1.2
1. Update Screenshot.
2. Solved Theme Review Issue.
3. Add Credits Link.
@version 1.1
1. Solved Theme Review Issue.
@version 1.0
1. Relesed
# --- EOF --- #